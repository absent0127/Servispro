# ServisPro V9

ServisPro oto servis yönetim SaaS'ının Supabase Auth + SSR entegrasyonlu sürümüdür.

## 1. Kurulum

```bash
npm install
```

`.env.example` dosyasını `.env.local` olarak kopyalayın ve Supabase bilgilerinizi girin.

```bash
cp .env.example .env.local
```

V9 için kullanılan public değişkenler:

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`

`SUPABASE_SERVICE_ROLE_KEY` yalnızca server-side ödeme callback gibi güvenilir işlemler için kullanılır; tarayıcıya koymayın ve kimseyle paylaşmayın.

## 2. Supabase SQL

Supabase SQL Editor'da sırasıyla:

1. `supabase/schema.sql`
2. `supabase/v4-migration.sql`
3. `supabase/v5-migration.sql`
4. `supabase/v6-migration.sql`
5. `supabase/v7-migration.sql`
6. `supabase/v8-migration.sql`
7. `supabase/v9-migration.sql`

çalıştırılmalıdır.

## 3. Lokal çalıştırma

```bash
npm run dev
```

Ardından `/register` üzerinden servis hesabı oluşturun.

Kayıt sonrası ilk `/dashboard` isteğinde işletme ve owner üyeliği oluşturulur.

## 4. Canlıya çıkış

Hosting tarafında aynı environment değişkenlerini ekleyin. PayTR canlı bilgileri ayrıca eklenmelidir.

- `NEXT_PUBLIC_APP_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `PAYTR_MERCHANT_ID`
- `PAYTR_MERCHANT_KEY`
- `PAYTR_MERCHANT_SALT`
- `PAYTR_TEST_MODE=0`

Service role key yalnızca server environment variable olarak tutulmalıdır.
