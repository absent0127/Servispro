"use server";
import { db } from "../lib/supabase/server";
import { revalidatePath } from "next/cache";
async function ctx(){const s=await db();const {data:{user}}=await s.auth.getUser();if(!user)throw Error("Oturum gerekli");const {data:b}=await s.from("businesses").select("id,name").eq("owner_id",user.id).single();if(!b)throw Error("İşletme bulunamadı");return{s,bid:b.id,business:b}}
export async function addCustomer(f:FormData){const{s,bid}=await ctx();await s.from("customers").insert({business_id:bid,name:String(f.get("name")),phone:String(f.get("phone")||""),email:String(f.get("email")||""),notes:String(f.get("notes")||"")});revalidatePath("/customers")}
export async function deleteCustomer(f:FormData){const{s,bid}=await ctx();await s.from("customers").delete().eq("id",String(f.get("id"))).eq("business_id",bid);revalidatePath("/customers")}
export async function addVehicle(f:FormData){const{s,bid}=await ctx();await s.from("vehicles").insert({business_id:bid,customer_id:String(f.get("customer_id")),plate:String(f.get("plate")),brand:String(f.get("brand")||""),model:String(f.get("model")||""),mileage:Number(f.get("mileage")||0)});revalidatePath("/vehicles")}
export async function deleteVehicle(f:FormData){const{s,bid}=await ctx();await s.from("vehicles").delete().eq("id",String(f.get("id"))).eq("business_id",bid);revalidatePath("/vehicles")}
export async function addOrder(f:FormData){const{s,bid}=await ctx();const {data:o,error}=await s.from("work_orders").insert({business_id:bid,customer_id:String(f.get("customer_id")),vehicle_id:String(f.get("vehicle_id")),description:String(f.get("description")||""),total:0,notes:String(f.get("notes")||""),status:"open"}).select("id").single();if(error)throw Error(error.message);const raw=String(f.get("items_json")||"[]");const items=JSON.parse(raw) as {item_type:string,name:string,quantity:number,unit_price:number}[];if(items.length)await s.from("work_order_items").insert(items.map(i=>({...i,business_id:bid,work_order_id:o.id})));await recalc(o.id,bid,s);revalidatePath("/work-orders")}
async function recalc(id:string,bid:string,s:any){const {data}=await s.from("work_order_items").select("quantity,unit_price").eq("work_order_id",id).eq("business_id",bid);const total=(data||[]).reduce((a:any,x:any)=>a+Number(x.quantity)*Number(x.unit_price),0);await s.from("work_orders").update({total}).eq("id",id).eq("business_id",bid)}
export async function updateOrderStatus(f:FormData){const{s,bid}=await ctx();await s.from("work_orders").update({status:String(f.get("status"))}).eq("id",String(f.get("id"))).eq("business_id",bid);revalidatePath("/work-orders");revalidatePath("/service-history")}
export async function deleteOrder(f:FormData){const{s,bid}=await ctx();await s.from("work_orders").delete().eq("id",String(f.get("id"))).eq("business_id",bid);revalidatePath("/work-orders")}
export async function addAppointment(f:FormData){const{s,bid}=await ctx();await s.from("appointments").insert({business_id:bid,customer_id:String(f.get("customer_id")),vehicle_id:String(f.get("vehicle_id")),starts_at:String(f.get("starts_at")),service:String(f.get("service")||""),status:"scheduled"});revalidatePath("/appointments")}
export async function addOrderItem(f:FormData){const{s,bid}=await ctx();const id=String(f.get("work_order_id"));await s.from("work_order_items").insert({business_id:bid,work_order_id:id,item_type:String(f.get("item_type")),name:String(f.get("name")),quantity:Number(f.get("quantity")||1),unit_price:Number(f.get("unit_price")||0)});await recalc(id,bid,s);revalidatePath(`/work-orders/${id}`);revalidatePath("/work-orders")}
export async function deleteOrderItem(f:FormData){const{s,bid}=await ctx();const id=String(f.get("work_order_id"));await s.from("work_order_items").delete().eq("id",String(f.get("id"))).eq("business_id",bid);await recalc(id,bid,s);revalidatePath(`/work-orders/${id}`);revalidatePath("/work-orders")}
export async function uploadOrderPhoto(f:FormData){const{s,bid}=await ctx();const id=String(f.get("work_order_id"));const file=f.get("photo");if(!(file instanceof File)||file.size===0)throw Error("Fotoğraf seçilmedi");if(file.size>8*1024*1024)throw Error("Fotoğraf 8 MB'dan küçük olmalı");const safe=file.name.replace(/[^a-zA-Z0-9._-]/g,"-");const path=`${bid}/${id}/${crypto.randomUUID()}-${safe}`;const up=await s.storage.from("work-order-photos").upload(path,file,{contentType:file.type||"image/jpeg",upsert:false});if(up.error)throw Error(up.error.message);const ins=await s.from("work_order_photos").insert({business_id:bid,work_order_id:id,storage_path:path,file_name:file.name});if(ins.error){await s.storage.from("work-order-photos").remove([path]);throw Error(ins.error.message)}revalidatePath(`/work-orders/${id}`)}
export async function deleteOrderPhoto(f:FormData){const{s,bid}=await ctx();const id=String(f.get("work_order_id"));const path=String(f.get("storage_path"));await s.storage.from("work-order-photos").remove([path]);await s.from("work_order_photos").delete().eq("id",String(f.get("id"))).eq("business_id",bid);revalidatePath(`/work-orders/${id}`)}

export async function ensureBusiness() {
  const s = await db()
  const { data: { user } } = await s.auth.getUser()
  if (!user) throw Error('Oturum gerekli')
  const { data: existing } = await s.from('businesses').select('id,name').eq('owner_id', user.id).maybeSingle()
  if (existing) return existing
  const businessName = String(user.user_metadata?.business_name || 'ServisPro İşletmem').trim() || 'ServisPro İşletmem'
  const { data: business, error } = await s.from('businesses').insert({ name: businessName, owner_id: user.id }).select('id,name').single()
  if (error) throw Error(error.message)
  await s.from('business_members').upsert({ business_id: business.id, user_id: user.id, role: 'owner' }, { onConflict: 'business_id,user_id' })
  return business
}

export async function signOut() {
  const s = await db()
  await s.auth.signOut()
  revalidatePath('/', 'layout')
}
