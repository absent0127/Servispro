import { NextResponse } from 'next/server'

export async function POST() {
  return NextResponse.json({
    ok: false,
    message: 'Ödeme sağlayıcısı henüz bağlanmadı. Provider webhook ve API anahtarları eklendiğinde bu endpoint gerçek checkout oturumuna yönlendirecek.'
  }, { status: 501 })
}
