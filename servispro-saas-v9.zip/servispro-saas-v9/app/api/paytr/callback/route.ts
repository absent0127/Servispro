import { NextRequest, NextResponse } from 'next/server'
import crypto from 'crypto'
import { adminDb } from '../../../../lib/supabase/admin'

export async function POST(req: NextRequest) {
  const form = await req.formData()
  const merchantOid = String(form.get('merchant_oid') || '')
  const status = String(form.get('status') || '')
  const totalAmount = String(form.get('total_amount') || '')
  const hash = String(form.get('hash') || '')

  const merchantKey = process.env.PAYTR_MERCHANT_KEY
  const merchantSalt = process.env.PAYTR_MERCHANT_SALT
  if (!merchantKey || !merchantSalt || !merchantOid || !hash) return new NextResponse('OK')

  const expected = crypto.createHmac('sha256', merchantKey)
    .update(`${merchantOid}${merchantSalt}${status}${totalAmount}`)
    .digest('base64')

  const a = Buffer.from(hash)
  const b = Buffer.from(expected)
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return new NextResponse('OK')
  }

  const supabase = adminDb()
  const { data: attempt } = await supabase
    .from('payment_attempts')
    .select('*')
    .eq('merchant_oid', merchantOid)
    .maybeSingle()

  if (!attempt) return new NextResponse('OK')

  // PayTR may retry the same notification. Never grant the subscription twice.
  if (attempt.status === 'paid' || attempt.status === 'failed') {
    return new NextResponse('OK')
  }

  if (status === 'success') {
    await supabase.from('payment_attempts').update({
      status: 'paid',
      paid_at: new Date().toISOString(),
      provider_total_amount: Number(totalAmount) / 100,
    }).eq('merchant_oid', merchantOid).eq('status', 'pending')

    const now = new Date()
    const end = new Date(now.getTime() + 30 * 86400000)
    await supabase.from('subscriptions').update({
      plan_code: attempt.plan_code,
      status: 'active',
      current_period_start: now.toISOString(),
      current_period_end: end.toISOString(),
      canceled_at: null,
      cancel_at_period_end: false,
    }).eq('business_id', attempt.business_id)
  } else {
    await supabase.from('payment_attempts').update({
      status: 'failed',
      failed_at: new Date().toISOString(),
      failure_reason: String(form.get('failed_reason_msg') || ''),
    }).eq('merchant_oid', merchantOid).eq('status', 'pending')
  }

  return new NextResponse('OK')
}
