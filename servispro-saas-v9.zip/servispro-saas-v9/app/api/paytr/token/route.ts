import { NextRequest, NextResponse } from 'next/server'
import crypto from 'crypto'
import { db } from '../../../../lib/supabase/server'

const PLAN_PRICES: Record<string, number> = { starter: 499, pro: 999, enterprise: 1999 }

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}))
  const plan = String(body.plan || 'starter')
  if (!(plan in PLAN_PRICES)) return NextResponse.json({ error: 'Geçersiz plan' }, { status: 400 })

  const merchantId = process.env.PAYTR_MERCHANT_ID
  const merchantKey = process.env.PAYTR_MERCHANT_KEY
  const merchantSalt = process.env.PAYTR_MERCHANT_SALT
  const appUrl = process.env.NEXT_PUBLIC_APP_URL
  if (!merchantId || !merchantKey || !merchantSalt || !appUrl) {
    return NextResponse.json({ error: 'PayTR ortam değişkenleri eksik.' }, { status: 500 })
  }

  const supabase = await db()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Giriş gerekli' }, { status: 401 })

  const { data: business } = await supabase.from('businesses').select('id,name').eq('owner_id', user.id).single()
  if (!business) return NextResponse.json({ error: 'İşletme bulunamadı' }, { status: 404 })

  const merchantOid = `SP-${business.id.slice(0,8)}-${Date.now()}`
  const amountKurus = Math.round(PLAN_PRICES[plan] * 100)
  const userIp = (req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || '127.0.0.1').split(',')[0].trim()
  const userBasket = Buffer.from(JSON.stringify([[`ServisPro ${plan} abonelik`, PLAN_PRICES[plan].toFixed(2), 1]])).toString('base64')
  const noInstallment = '1'
  const maxInstallment = '0'
  const currency = 'TL'
  const testMode = process.env.PAYTR_TEST_MODE || '1'
  const debugOn = process.env.NODE_ENV === 'production' ? '0' : '1'

  const hashStr = `${merchantId}${userIp}${merchantOid}${user.email || 'musteri@example.com'}${amountKurus}${userBasket}${noInstallment}${maxInstallment}${currency}${testMode}${merchantSalt}`
  const paytrToken = crypto.createHmac('sha256', merchantKey).update(hashStr).digest('base64')

  const form = new URLSearchParams({
    merchant_id: merchantId,
    user_ip: userIp,
    merchant_oid: merchantOid,
    email: user.email || 'musteri@example.com',
    payment_amount: String(amountKurus),
    paytr_token: paytrToken,
    user_basket: userBasket,
    debug_on: debugOn,
    no_installment: noInstallment,
    max_installment: maxInstallment,
    user_name: business.name,
    user_address: 'Türkiye',
    user_phone: '0000000000',
    merchant_ok_url: `${appUrl}/payment/success?oid=${encodeURIComponent(merchantOid)}`,
    merchant_fail_url: `${appUrl}/payment/fail?oid=${encodeURIComponent(merchantOid)}`,
    timeout_limit: '30',
    currency,
    test_mode: testMode,
    lang: 'tr',
    iframe_v2: '1',
  })

  const response = await fetch('https://www.paytr.com/odeme/api/get-token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: form,
  })
  const result = await response.json()
  if (result.status !== 'success') return NextResponse.json({ error: result.reason || 'PayTR token alınamadı' }, { status: 502 })

  await supabase.from('payment_attempts').insert({
    business_id: business.id,
    merchant_oid: merchantOid,
    provider: 'paytr',
    plan_code: plan,
    amount_try: PLAN_PRICES[plan],
    status: 'pending',
  })

  return NextResponse.json({ iframeToken: result.token, merchantOid })
}
