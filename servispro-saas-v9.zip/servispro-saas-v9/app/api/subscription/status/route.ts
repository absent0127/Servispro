import { NextResponse } from 'next/server'
import { db } from '../../../../lib/supabase/server'

export async function GET() {
  const s = await db()
  const { data: { user } } = await s.auth.getUser()
  if (!user) return NextResponse.json({ authenticated: false }, { status: 401 })
  const { data: business } = await s.from('businesses').select('id,name').eq('owner_id', user.id).single()
  if (!business) return NextResponse.json({ authenticated: true, business: null })
  const { data: subscription } = await s.from('subscriptions').select('*').eq('business_id', business.id).single()
  return NextResponse.json({ authenticated: true, business, subscription })
}
