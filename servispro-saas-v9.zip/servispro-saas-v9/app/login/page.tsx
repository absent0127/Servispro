'use client'

import { FormEvent, useState } from 'react'
import Link from 'next/link'
import { createClient } from '../../utils/supabase/client'
import { useRouter } from 'next/navigation'

export default function LoginPage() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(e: FormEvent) {
    e.preventDefault(); setLoading(true); setError('')
    const supabase = createClient()
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) { setError(error.message); setLoading(false); return }
    router.push('/dashboard'); router.refresh()
  }

  return <main className="auth-shell"><section className="auth-card"><div className="logo">SP</div><h1>ServisPro'ya giriş yap</h1><p className="muted">Servis yönetim paneline devam et.</p><form onSubmit={submit} className="form"><input type="email" placeholder="E-posta" value={email} onChange={e=>setEmail(e.target.value)} required/><input type="password" placeholder="Şifre" value={password} onChange={e=>setPassword(e.target.value)} required/><button className="button primary" disabled={loading}>{loading?'Giriş yapılıyor…':'Giriş yap'}</button>{error&&<p className="notice">{error}</p>}</form><p className="muted">Hesabın yok mu? <Link href="/register">Ücretsiz hesap oluştur</Link></p></section></main>
}
