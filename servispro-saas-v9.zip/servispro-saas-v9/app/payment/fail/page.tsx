import Link from 'next/link'
export default function PaymentFail(){ return <main className="container"><section className="card"><span className="badge">ÖDEME BAŞARISIZ</span><h1>Ödeme tamamlanamadı.</h1><p className="muted">Kart veya ödeme yönteminizi kontrol edip tekrar deneyebilirsiniz.</p><Link className="button" href="/pricing">Planlara dön</Link></section></main> }
