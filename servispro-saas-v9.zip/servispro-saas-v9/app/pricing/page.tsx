import Link from 'next/link'

const plans = [
  {name:'Başlangıç', price:'499', desc:'Küçük servisler için', features:['Müşteri ve araç yönetimi','İş emri ve servis geçmişi','Randevu takvimi','Temel raporlar']},
  {name:'Profesyonel', price:'999', desc:'Büyüyen servisler için', popular:true, features:['Başlangıç planındaki her şey','Parça + işçilik detayları','Fotoğraf arşivi','Ekip üyeleri ve roller','Gelişmiş raporlar']},
  {name:'Kurumsal', price:'1.999', desc:'Çok kullanıcılı işletmeler için', features:['Profesyonel planındaki her şey','Öncelikli destek','Gelişmiş yetkilendirme','API / entegrasyon altyapısı','Çoklu şube altyapısı']}
]

export default function PricingPage(){return <main className="container"><div className="hero"><p className="eyebrow">SERVİSPRO</p><h1>Servisini tek panelden yönet.</h1><p className="muted">Müşteri, araç, iş emri, randevu ve servis geçmişini tek yerde topla.</p></div><div className="grid pricing-grid">{plans.map(p=><section className={'card plan '+(p.popular?'popular':'')} key={p.name}>{p.popular&&<span className="badge">EN ÇOK TERCİH EDİLEN</span>}<h2>{p.name}</h2><p className="muted">{p.desc}</p><div className="price">₺{p.price}<small>/ay</small></div><ul>{p.features.map(f=><li key={f}>✓ {f}</li>)}</ul><Link className="button primary full" href="/settings/billing">Planı seç</Link></section>)}</div></main>}
