'use client'

import { FormEvent, useState } from 'react'
import Link from 'next/link'
import { createClient } from '../../utils/supabase/client'
import { useRouter } from 'next/navigation'

export default function RegisterPage() {
  const router = useRouter()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(e: FormEvent) {
    e.preventDefault(); setLoading(true); setError(''); setMessage('')
    const supabase = createClient()
    const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { business_name: name } } })
    if (error) { setError(error.message); setLoading(false); return }
    if (data.session) { router.push('/dashboard'); router.refresh(); return }
    setMessage('Kayıt oluşturuldu. E-posta doğrulaması açıksa gelen kutunu kontrol et.')
    setLoading(false)
  }

  return <main className="auth-shell"><section className="auth-card"><div className="logo">SP</div><h1>ServisPro hesabı oluştur</h1><p className="muted">14 günlük deneme altyapısıyla başla.</p><form onSubmit={submit} className="form"><input placeholder="Servis adı" value={name} onChange={e=>setName(e.target.value)} required/><input type="email" placeholder="E-posta" value={email} onChange={e=>setEmail(e.target.value)} required/><input type="password" placeholder="Şifre (en az 6 karakter)" minLength={6} value={password} onChange={e=>setPassword(e.target.value)} required/><button className="button primary" disabled={loading}>{loading?'Hesap oluşturuluyor…':'Hesap oluştur'}</button>{error&&<p className="notice">{error}</p>}{message&&<p className="notice">{message}</p>}</form><p className="muted">Zaten hesabın var mı? <Link href="/login">Giriş yap</Link></p></section></main>
}
