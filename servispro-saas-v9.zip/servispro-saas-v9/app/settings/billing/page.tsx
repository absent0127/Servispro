'use client'
import { useState } from 'react'
import Link from 'next/link'
const plans=[['starter','Başlangıç','499'],['pro','Profesyonel','999'],['enterprise','Kurumsal','1.999']]
export default function Billing(){
 const [plan,setPlan]=useState('pro'); const [token,setToken]=useState(''); const [loading,setLoading]=useState(false); const [error,setError]=useState('')
 async function pay(){ setLoading(true); setError(''); const r=await fetch('/api/paytr/token',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({plan})}); const d=await r.json(); if(!r.ok){setError(d.error||'Ödeme başlatılamadı');setLoading(false);return} setToken(d.iframeToken);setLoading(false) }
 return <main className="container"><div className="topbar"><div><p className="eyebrow">ABONELİK</p><h1>Faturalandırma</h1><p className="muted">PayTR ödeme kurulumu</p></div><Link className="button" href="/pricing">Planları karşılaştır</Link></div><section className="card"><h2>Plan seç</h2><div className="grid-3">{plans.map(([id,name,price])=><button key={id} className={plan===id?'button primary':'button'} onClick={()=>setPlan(id)}><b>{name}</b><br/>₺{price}/ay</button>)}</div><br/><button className="button primary" onClick={pay} disabled={loading}>{loading?'Ödeme hazırlanıyor…':'PayTR ile ödemeye geç'}</button>{error&&<p className="notice">{error}</p>}</section>{token&&<section className="card"><h2>Güvenli ödeme</h2><iframe src={`https://www.paytr.com/odeme/guvenli/${token}`} style={{width:'100%',minHeight:700,border:0}} title="PayTR ödeme" /></section>}</main>
}
