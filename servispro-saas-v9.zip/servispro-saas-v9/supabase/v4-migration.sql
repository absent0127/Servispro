-- ServisPro V4 migration
create table if not exists public.work_order_items(
 id uuid primary key default uuid_generate_v4(),
 business_id uuid not null references public.businesses(id) on delete cascade,
 work_order_id uuid not null references public.work_orders(id) on delete cascade,
 item_type text not null default 'labor' check(item_type in ('labor','part')),
 name text not null,
 quantity numeric(12,2) not null default 1,
 unit_price numeric(12,2) not null default 0,
 created_at timestamptz default now()
);
create table if not exists public.work_order_photos(
 id uuid primary key default uuid_generate_v4(),
 business_id uuid not null references public.businesses(id) on delete cascade,
 work_order_id uuid not null references public.work_orders(id) on delete cascade,
 storage_path text not null,
 file_name text not null,
 created_at timestamptz default now()
);
alter table public.work_order_items enable row level security;
alter table public.work_order_photos enable row level security;
create policy "order item access" on public.work_order_items for all using(public.is_business_member(business_id)) with check(public.is_business_member(business_id));
create policy "order photo access" on public.work_order_photos for all using(public.is_business_member(business_id)) with check(public.is_business_member(business_id));

insert into storage.buckets(id,name,public) values('work-order-photos','work-order-photos',false) on conflict(id) do nothing;
create policy "photo read" on storage.objects for select to authenticated using(bucket_id='work-order-photos' and public.is_business_member((storage.foldername(name))[1]::uuid));
create policy "photo insert" on storage.objects for insert to authenticated with check(bucket_id='work-order-photos' and public.is_business_member((storage.foldername(name))[1]::uuid));
create policy "photo delete" on storage.objects for delete to authenticated using(bucket_id='work-order-photos' and public.is_business_member((storage.foldername(name))[1]::uuid));
