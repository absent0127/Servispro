-- ServisPro V5: subscription foundation
create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  plan_code text not null default 'starter' check (plan_code in ('starter','pro','enterprise')),
  status text not null default 'active' check (status in ('trialing','active','past_due','canceled')),
  provider text,
  provider_customer_id text,
  provider_subscription_id text,
  current_period_start timestamptz,
  current_period_end timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(business_id)
);

alter table public.subscriptions enable row level security;

create policy "members can read subscription" on public.subscriptions
for select using (public.is_business_member(business_id));

create policy "owners can manage subscription" on public.subscriptions
for all using (public.is_business_owner(business_id)) with check (public.is_business_owner(business_id));

insert into public.subscriptions (business_id, plan_code, status)
select b.id, 'starter', 'active'
from public.businesses b
where not exists (select 1 from public.subscriptions s where s.business_id=b.id);
