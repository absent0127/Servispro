-- ServisPro V6: trial + plan limits + feature flags
alter table public.subscriptions
  add column if not exists trial_ends_at timestamptz,
  add column if not exists canceled_at timestamptz,
  add column if not exists cancel_at_period_end boolean not null default false;

update public.subscriptions
set trial_ends_at = coalesce(trial_ends_at, created_at + interval '14 days')
where status = 'trialing' or trial_ends_at is null;

-- Plan catalog used by the application. Prices are stored in kuruş.
create table if not exists public.plan_catalog (
  code text primary key,
  name text not null,
  monthly_price_try integer not null check (monthly_price_try >= 0),
  max_staff integer not null,
  max_vehicles integer not null,
  max_work_orders_month integer not null,
  features jsonb not null default '{}'::jsonb,
  active boolean not null default true
);

insert into public.plan_catalog(code,name,monthly_price_try,max_staff,max_vehicles,max_work_orders_month,features)
values
('starter','Başlangıç',49900,2,500,200,'{"photos":false,"advanced_reports":false,"api":false}'::jsonb),
('pro','Profesyonel',99900,10,5000,2000,'{"photos":true,"advanced_reports":true,"api":false}'::jsonb),
('enterprise','Kurumsal',199900,999999,999999,999999,'{"photos":true,"advanced_reports":true,"api":true,"multi_branch":true}'::jsonb)
on conflict (code) do update set name=excluded.name, monthly_price_try=excluded.monthly_price_try,
max_staff=excluded.max_staff,max_vehicles=excluded.max_vehicles,max_work_orders_month=excluded.max_work_orders_month,
features=excluded.features;

alter table public.plan_catalog enable row level security;
create policy "anyone can read active plans" on public.plan_catalog for select using (active = true);

-- Existing businesses receive a 14-day trial on Starter if they have no active subscription.
insert into public.subscriptions (business_id, plan_code, status, trial_ends_at)
select b.id, 'starter', 'trialing', now() + interval '14 days'
from public.businesses b
where not exists (select 1 from public.subscriptions s where s.business_id=b.id);
