-- ServisPro V7: PayTR payment attempts
create table if not exists public.payment_attempts (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  merchant_oid text not null unique,
  provider text not null default 'paytr',
  plan_code text not null references public.plan_catalog(code),
  amount_try numeric(12,2) not null,
  status text not null default 'pending' check (status in ('pending','paid','failed')),
  paid_at timestamptz,
  failed_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.payment_attempts enable row level security;
create policy "members can read payment attempts" on public.payment_attempts for select using (exists (select 1 from public.business_members bm where bm.business_id = payment_attempts.business_id and bm.user_id = auth.uid()));
create index if not exists payment_attempts_business_idx on public.payment_attempts(business_id, created_at desc);
