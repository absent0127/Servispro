-- ServisPro V8: hardened PayTR payment records
alter table public.payment_attempts
  add column if not exists provider_total_amount numeric(12,2),
  add column if not exists failure_reason text,
  add column if not exists test_mode boolean not null default true;

create index if not exists payment_attempts_status_idx
  on public.payment_attempts(status, created_at desc);

-- Server callbacks use SUPABASE_SERVICE_ROLE_KEY and do not rely on a user session.
