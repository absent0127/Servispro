-- ServisPro V9: Supabase Auth bootstrap helper.
-- The app creates the business after the first authenticated dashboard request,
-- so no service_role key is required in the browser.

create index if not exists businesses_owner_idx on public.businesses(owner_id);
create index if not exists business_members_user_idx on public.business_members(user_id);

-- Allow the authenticated owner to create their own business.
drop policy if exists "business owner insert" on public.businesses;
create policy "business owner insert" on public.businesses
for insert to authenticated
with check (owner_id = auth.uid());

-- Allow an owner/member to create the membership row for the business they own.
drop policy if exists "member self insert" on public.business_members;
create policy "member self insert" on public.business_members
for insert to authenticated
with check (
  user_id = auth.uid()
  and exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())
);
